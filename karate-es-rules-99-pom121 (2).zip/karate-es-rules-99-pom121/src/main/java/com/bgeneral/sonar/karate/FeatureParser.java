package com.bgeneral.sonar.karate;
import com.bgeneral.sonar.karate.model.ParsedFeature;
import com.bgeneral.sonar.karate.model.ParsedScenario;
import java.util.*; import java.util.regex.*;
public class FeatureParser {
  private static final Pattern TAGS = Pattern.compile("^\\s*@([A-Za-z0-9_-]+)");
  private static final Pattern FEATURE = Pattern.compile("^(?:\\s*(?:Feature:?|Característica:?))");
  private static final Pattern SCENARIO = Pattern.compile("^\\s*(?:Scenario Outline|Scenario|Escenario Esquema|Escenario):");
  public static ParsedFeature parse(String path, java.util.List<String> lines) {
    ParsedFeature pf = new ParsedFeature(); pf.path = path;
    java.util.List<String> pendingTags = new ArrayList<>(); java.util.List<Integer> pendingTagLines = new ArrayList<>();
    for (int i=0;i<lines.size();i++) {
      String line = lines.get(i);
      Matcher t = TAGS.matcher(line);
      if (t.find()) { pendingTags.addAll(extractTagsFromLine(line)); pendingTagLines.add(i+1); continue; }
      if (FEATURE.matcher(line).find()) { pf.featureLine = i+1; pf.fileTags.addAll(pendingTags); pendingTags.clear(); pendingTagLines.clear(); continue; }
      Matcher s = SCENARIO.matcher(line);
      if (s.find()) { ParsedScenario sc = new ParsedScenario(); sc.type="Scenario"; sc.name=line.trim(); sc.line=i+1; sc.tags.addAll(pendingTags); sc.tagLines.addAll(pendingTagLines); pf.scenarios.add(sc); pendingTags.clear(); pendingTagLines.clear(); continue; }
      if (!pf.scenarios.isEmpty()) { ParsedScenario sc = pf.scenarios.get(pf.scenarios.size()-1); if (!line.trim().isEmpty()) { sc.steps.add(line); sc.stepLines.add(i+1);} }
    } return pf;
  }
  private static java.util.List<String> extractTagsFromLine(String line) {
    java.util.List<String> tags = new ArrayList<>(); for (String token : line.trim().split("\\s+")) { if (token.startsWith("@")) { tags.add(token.substring(1)); } } return tags;
  }
}