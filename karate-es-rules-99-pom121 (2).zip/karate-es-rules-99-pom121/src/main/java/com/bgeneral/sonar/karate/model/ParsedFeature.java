package com.bgeneral.sonar.karate.model;
import java.util.ArrayList; import java.util.List;
public class ParsedFeature {
  public String path; public List<String> fileTags = new ArrayList<>();
  public int featureLine = -1; public List<ParsedScenario> scenarios = new ArrayList<>();
}