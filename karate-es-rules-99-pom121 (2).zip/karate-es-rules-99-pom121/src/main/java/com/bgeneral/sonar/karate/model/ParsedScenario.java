package com.bgeneral.sonar.karate.model;
import java.util.ArrayList; import java.util.List;
public class ParsedScenario {
  public String type; public String name; public int line;
  public List<String> tags = new ArrayList<>(); public List<Integer> tagLines = new ArrayList<>();
  public List<String> steps = new ArrayList<>(); public List<Integer> stepLines = new ArrayList<>();
}