package com.bgeneral.sonar.karate;

import org.sonar.api.server.rule.RulesDefinition;

public class KarateRulesDefinition implements RulesDefinition {

  // Repositorio y lenguaje (usar uno que SI exista en el server)
  public static final String REPO_KEY = "karate";
  public static final String LANG_KEY = "java";

  // Claves de reglas
  public static final String R_PROJECT_HAS_CORE_TAGS   = "KARATE_PROJECT_HAS_CORE_TAGS";
  public static final String R_MAX_TAGS_PER_SCENARIO   = "KARATE_MAX_TAGS_PER_SCENARIO";
  public static final String R_UPPERCASE_KEYWORDS      = "KARATE_UPPERCASE_KEYWORDS";
  public static final String R_TAGS_ABOVE_SCENARIO     = "KARATE_TAGS_ABOVE_SCENARIO";
  public static final String R_HAS_VALIDATIONS         = "KARATE_HAS_VALIDATIONS";
  public static final String R_NO_HARDCODED_VARS       = "KARATE_NO_HARDCODED_VARS";
  public static final String R_DEF_AT_BEGIN            = "KARATE_DEF_AT_BEGIN";
  public static final String R_MAX_15_SCENARIOS        = "KARATE_MAX_15_SCENARIOS";
  public static final String R_MAX_3_AND               = "KARATE_MAX_3_AND";

  @Override
  public void define(Context context) {
    NewRepository repo = context.createRepository(REPO_KEY, LANG_KEY)
            .setName("Karate Rules (ES)");

    // 1) Proyecto con al menos @smokeTest o @regressionTest
    repo.createRule(R_PROJECT_HAS_CORE_TAGS)
            .setName("El proyecto debe tener @smokeTest o @regressionTest")
            .setHtmlDescription("Debe existir al menos un tag <code>@smokeTest</code> o <code>@regressionTest</code> en algún archivo <code>.feature</code> del proyecto.");

    // 2) Máximo 8 tags por escenario
    repo.createRule(R_MAX_TAGS_PER_SCENARIO)
            .setName("Máximo 8 tags por escenario")
            .setHtmlDescription("Limita la cantidad de tags por escenario a 8 para mantener trazabilidad y legibilidad.");

    // 3) Keywords en mayúsculas (DADO, CUANDO, Y, ENTONCES)
    repo.createRule(R_UPPERCASE_KEYWORDS)
            .setName("Keywords en mayúsculas (DADO, CUANDO, Y, ENTONCES)")
            .setHtmlDescription("Las palabras clave de pasos deben escribirse en mayúsculas: <code>DADO</code>, <code>CUANDO</code>, <code>Y</code>, <code>ENTONCES</code>.");

    // 4/9) Tags por encima del escenario
    repo.createRule(R_TAGS_ABOVE_SCENARIO)
            .setName("Los tags deben estar por encima del escenario")
            .setHtmlDescription("Los tags deben ubicarse inmediatamente sobre el encabezado del <em>Scenario</em> o <em>Scenario Outline</em>.");

    // 5) Validaciones obligatorias (match/assert) distintas de status==200 y sin U0000
    repo.createRule(R_HAS_VALIDATIONS)
            .setName("Validaciones obligatorias por escenario")
            .setHtmlDescription("Cada escenario debe incluir al menos un <code>match</code> o <code>assert</code> significativo (distinto a comprobar solo <code>status==200</code> y sin contener <code>U0000</code>).");

    // 6) No tener variables hardcoded en * def
    repo.createRule(R_NO_HARDCODED_VARS)
            .setName("Variables hardcodeadas prohibidas")
            .setHtmlDescription("Evita <code>* def</code> con literales (cadenas/números/booleanos) fijos. Usa variables externas, tablas de datos o configuraciones.");

    // 7) * def al principio del escenario o en Background
    repo.createRule(R_DEF_AT_BEGIN)
            .setName("* def al inicio del escenario o en Background")
            .setHtmlDescription("Debe existir al menos un <code>* def</code> al comienzo del <em>Scenario</em>/<em>Scenario Outline</em> (primeras líneas) o definido en <em>Background</em>.");

    // 8) Máximo 15 escenarios por feature
    repo.createRule(R_MAX_15_SCENARIOS)
            .setName("Máximo 15 escenarios por feature")
            .setHtmlDescription("Limita el número de escenarios por archivo <code>.feature</code> a 15 para mantenerlo manejable.");

    // 10) Máximo 3 'Y' por escenario
    repo.createRule(R_MAX_3_AND)
            .setName("Máximo 3 'Y' por escenario")
            .setHtmlDescription("Restringe el uso de pasos con <code>Y</code> a un máximo de 3 para evitar escenarios demasiado secuenciales/complejos.");

    repo.done();
  }
}
