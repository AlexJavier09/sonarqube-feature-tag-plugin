package com.bgeneral.sonar.karate;
import org.sonar.api.Plugin;
public class KaratePlugin implements Plugin {
  @Override public void define(Context context) {
    context.addExtensions(KarateRulesDefinition.class, KarateProfile.class, KarateSensor.class);
  }
}