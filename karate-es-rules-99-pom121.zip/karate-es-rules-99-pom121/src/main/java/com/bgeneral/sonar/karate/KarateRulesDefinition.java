package com.bgeneral.sonar.karate;
import org.sonar.api.server.rule.RulesDefinition;
public class KarateRulesDefinition implements RulesDefinition {
  public static final String REPO_KEY = "karate";
  public static final String LANG_KEY = "text";
  public static final String R_PROJECT_HAS_CORE_TAGS = "KARATE_PROJECT_HAS_CORE_TAGS";
  public static final String R_MAX_TAGS_PER_SCENARIO = "KARATE_MAX_TAGS_PER_SCENARIO";
  public static final String R_UPPERCASE_KEYWORDS = "KARATE_UPPERCASE_KEYWORDS";
  public static final String R_TAGS_ABOVE_SCENARIO = "KARATE_TAGS_ABOVE_SCENARIO";
  public static final String R_HAS_VALIDATIONS = "KARATE_HAS_VALIDATIONS";
  public static final String R_NO_HARDCODED_VARS = "KARATE_NO_HARDCODED_VARS";
  public static final String R_DEF_AT_BEGIN = "KARATE_DEF_AT_BEGIN";
  public static final String R_MAX_15_SCENARIOS = "KARATE_MAX_15_SCENARIOS";
  public static final String R_MAX_3_AND = "KARATE_MAX_3_AND";
  @Override public void define(Context context) {
    NewRepository repo = context.createRepository(REPO_KEY, LANG_KEY).setName("Karate Rules (ES)");
    repo.createRule(R_PROJECT_HAS_CORE_TAGS).setName("El proyecto debe tener @smokeTest o @regressionTest");
    repo.createRule(R_MAX_TAGS_PER_SCENARIO).setName("Máximo 8 tags por escenario");
    repo.createRule(R_UPPERCASE_KEYWORDS).setName("Keywords en mayúsculas (DADO, CUANDO, Y, ENTONCES)");
    repo.createRule(R_TAGS_ABOVE_SCENARIO).setName("Tags por encima del escenario");
    repo.createRule(R_HAS_VALIDATIONS).setName("Validaciones obligatorias por escenario");
    repo.createRule(R_NO_HARDCODED_VARS).setName("Variables hardcodeadas prohibidas");
    repo.createRule(R_DEF_AT_BEGIN).setName("* def al inicio del escenario o en Background");
    repo.createRule(R_MAX_15_SCENARIOS).setName("Máximo 15 escenarios por feature");
    repo.createRule(R_MAX_3_AND).setName("Máximo 3 'Y' por escenario");
    repo.done();
  }
}