package com.bgeneral.sonar.karate;
import org.sonar.api.server.profile.BuiltInQualityProfilesDefinition;
public class KarateProfile implements BuiltInQualityProfilesDefinition {
  @Override public void define(Context context) {
    NewBuiltInQualityProfile profile = context.createBuiltInQualityProfile("Karate Way (ES)", KarateRulesDefinition.LANG_KEY);
    profile.activateRule(KarateRulesDefinition.REPO_KEY, KarateRulesDefinition.R_PROJECT_HAS_CORE_TAGS);
    profile.activateRule(KarateRulesDefinition.REPO_KEY, KarateRulesDefinition.R_MAX_TAGS_PER_SCENARIO);
    profile.activateRule(KarateRulesDefinition.REPO_KEY, KarateRulesDefinition.R_UPPERCASE_KEYWORDS);
    profile.activateRule(KarateRulesDefinition.REPO_KEY, KarateRulesDefinition.R_TAGS_ABOVE_SCENARIO);
    profile.activateRule(KarateRulesDefinition.REPO_KEY, KarateRulesDefinition.R_HAS_VALIDATIONS);
    profile.activateRule(KarateRulesDefinition.REPO_KEY, KarateRulesDefinition.R_NO_HARDCODED_VARS);
    profile.activateRule(KarateRulesDefinition.REPO_KEY, KarateRulesDefinition.R_DEF_AT_BEGIN);
    profile.activateRule(KarateRulesDefinition.REPO_KEY, KarateRulesDefinition.R_MAX_15_SCENARIOS);
    profile.activateRule(KarateRulesDefinition.REPO_KEY, KarateRulesDefinition.R_MAX_3_AND);
    profile.done();
  }
}