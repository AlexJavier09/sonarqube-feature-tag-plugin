package com.bgeneral.sonar.karate;
import com.bgeneral.sonar.karate.model.ParsedFeature;
import com.bgeneral.sonar.karate.model.ParsedScenario;
import org.sonar.api.batch.fs.*; import org.sonar.api.batch.sensor.*; import org.sonar.api.batch.sensor.issue.*; import org.sonar.api.rule.RuleKey;
import java.io.IOException; import java.nio.charset.StandardCharsets; import java.util.List; import java.util.regex.Pattern;
public class KarateSensor implements Sensor {
  private static final Pattern UPPERCASE_KEYWORDS = Pattern.compile("^\\s*(?:DADO|CUANDO|ENTONCES|Y)\\b");
  private static final Pattern LOWERCASE_KEYWORDS = Pattern.compile("^\\s*(?:Dado|Cuando|Entonces|Y|dado|cuando|entonces|y)\\b");
  private static final Pattern VALIDATION = Pattern.compile("\\b(?:match|assert)\\b");
  private static final Pattern STATUS_200 = Pattern.compile("status\\s*==\\s*200");
  private static final Pattern U0000 = Pattern.compile("U0000");
  private static final Pattern DEF_ASSIGN_LITERAL = Pattern.compile("^\\s*\\*\\s*def\\s+[A-Za-z_][A-Za-z0-9_]*\\s*=\\s*(?:\"[^\"]*\"|'[^']*'|[0-9]+(?:\\.[0-9]+)?|true|false|null)\\s*$");
  private static final Pattern DEF_LINE = Pattern.compile("^\\s*\\*\\s*def\\b");
  private boolean projectHasCoreTag = false; private InputFile firstFile = null;
  @Override public void describe(SensorDescriptor d) { d.name("Karate ES Rules Sensor"); }
  @Override public void execute(SensorContext ctx) {
    FileSystem fs = ctx.fileSystem(); FilePredicates p = fs.predicates();
    Iterable<InputFile> files = fs.inputFiles(p.matchesPathPatterns("**/*.feature"));
    for (InputFile f : files) {
      if (firstFile == null) firstFile = f;
      try {
        List<String> lines = java.nio.file.Files.readAllLines(f.path(), StandardCharsets.UTF_8);
        ParsedFeature pf = FeatureParser.parse(f.absolutePath(), lines); analyzeFile(ctx, f, pf);
      } catch (IOException e) { /* ignore */ }
    }
    if (!projectHasCoreTag && firstFile != null) reportProjectCoreTagMissing(ctx, firstFile);
  }
  private void analyzeFile(SensorContext ctx, InputFile file, ParsedFeature pf) {
    if (pf.scenarios.size() > 15) createIssue(ctx, file, KarateRulesDefinition.R_MAX_15_SCENARIOS, pf.featureLine>0?pf.featureLine:1, "El archivo contiene "+pf.scenarios.size()+" escenarios; máximo permitido es 15.");
    if (pf.fileTags.stream().anyMatch(t -> t.equals("smokeTest") || t.equals("regressionTest"))) projectHasCoreTag = true;
    for (com.bgeneral.sonar.karate.model.ParsedScenario sc : pf.scenarios) {
      if (sc.tags.stream().anyMatch(t -> t.equals("smokeTest") || t.equals("regressionTest"))) projectHasCoreTag = true;
      if (sc.tags.size() > 8) createIssue(ctx, file, KarateRulesDefinition.R_MAX_TAGS_PER_SCENARIO, sc.line, "Escenario con "+sc.tags.size()+" tags; máximo 8.");
      if (!sc.tags.isEmpty()) { boolean contiguous = sc.tagLines.stream().anyMatch(tl -> tl == sc.line-1 || tl == sc.line-2); if (!contiguous) createIssue(ctx, file, KarateRulesDefinition.R_TAGS_ABOVE_SCENARIO, sc.line, "Los tags deben ubicarse inmediatamente arriba del encabezado del escenario."); }
      for (int i=0;i<sc.steps.size();i++){ String step=sc.steps.get(i); int line=sc.stepLines.get(i);
        if (LOWERCASE_KEYWORDS.matcher(step).find() && !UPPERCASE_KEYWORDS.matcher(step).find()) createIssue(ctx, file, KarateRulesDefinition.R_UPPERCASE_KEYWORDS, line, "Usa keywords en mayúsculas: DADO, CUANDO, Y, ENTONCES."); }
      long yCount = sc.steps.stream().filter(s -> { String t = s.trim(); return t.equals("Y") || t.startsWith("Y "); }).count();
      if (yCount > 3) createIssue(ctx, file, KarateRulesDefinition.R_MAX_3_AND, sc.line, "Escenario usa 'Y' "+yCount+" veces; máximo 3.");
      boolean hasValid = sc.steps.stream().anyMatch(step -> { if (!VALIDATION.matcher(step).find()) return false; boolean onlyStatus200 = STATUS_200.matcher(step).find(); boolean containsU0000 = U0000.matcher(step).find(); return !onlyStatus200 && !containsU0000; });
      if (!hasValid) createIssue(ctx, file, KarateRulesDefinition.R_HAS_VALIDATIONS, sc.line, "Escenario sin match/assert válido distinto de status==200 y sin U0000.");
      for (int i=0;i<sc.steps.size();i++){ String step=sc.steps.get(i); int line=sc.stepLines.get(i);
        if (DEF_ASSIGN_LITERAL.matcher(step).find()) createIssue(ctx, file, KarateRulesDefinition.R_NO_HARDCODED_VARS, line, "Evita * def con literales hardcodeados; usa variables de entorno, data table o config."); }
      boolean defAtBegin=false; for (int i=0;i<Math.min(sc.steps.size(),5);i++){ if (DEF_LINE.matcher(sc.steps.get(i)).find()) { defAtBegin=true; break; } }
      if (!defAtBegin) createIssue(ctx, file, KarateRulesDefinition.R_DEF_AT_BEGIN, sc.line, "Debe existir al menos un '* def' al inicio del escenario (primeras líneas) o en Background.");
    }
  }
  private void reportProjectCoreTagMissing(SensorContext ctx, InputFile file) {
    createIssue(ctx, file, KarateRulesDefinition.R_PROJECT_HAS_CORE_TAGS, 1, "El proyecto debe contener al menos un tag @smokeTest o @regressionTest en algún .feature.");
  }
  private void createIssue(SensorContext ctx, InputFile file, String ruleKey, int line, String message) {
    RuleKey rk = RuleKey.of(KarateRulesDefinition.REPO_KEY, ruleKey); NewIssue issue = ctx.newIssue().forRule(rk);
    NewIssueLocation loc = issue.newLocation().on(file).message(message); try { if (line>0) loc.at(file.selectLine(line)); } catch (Exception ignored) {}
    issue.at(loc).save();
  }
}