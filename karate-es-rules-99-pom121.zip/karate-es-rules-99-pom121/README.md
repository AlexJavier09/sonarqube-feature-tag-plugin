# Karate ES Rules – SQ 9.9 (Java 17)

POM corregido para resolver sonar-plugin-api desde org.sonarsource.sonarqube.
